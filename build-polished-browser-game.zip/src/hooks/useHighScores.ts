import { useCallback, useMemo, useState } from 'react';

export interface ScoreEntry {
  name: string;
  score: number;
  date: string;
}

const STORAGE_KEY = 'neon-orbit-highscores-v1';
export const MAX_SCORES = 10;

function load(): ScoreEntry[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(
        (e): e is ScoreEntry =>
          !!e &&
          typeof e.name === 'string' &&
          typeof e.score === 'number' &&
          typeof e.date === 'string',
      )
      .sort((a, b) => b.score - a.score)
      .slice(0, MAX_SCORES);
  } catch {
    return [];
  }
}

function save(entries: ScoreEntry[]) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
  } catch {
    /* storage unavailable (private mode etc.) – ignore */
  }
}

/** Local high-score table persisted to localStorage (top 10). */
export function useHighScores() {
  const [scores, setScores] = useState<ScoreEntry[]>(load);

  const best = useMemo(() => (scores[0]?.score ?? 0), [scores]);

  const qualifies = useCallback(
    (score: number) =>
      score > 0 && (scores.length < MAX_SCORES || score > scores[scores.length - 1].score),
    [scores],
  );

  /** Inserts an entry, persists it, and returns its rank index (0-based) or -1. */
  const addScore = useCallback(
    (name: string, score: number): number => {
      const clean = name.trim().toUpperCase().slice(0, 3) || 'CPU';
      const entry: ScoreEntry = {
        name: clean,
        score,
        date: new Date().toISOString().slice(0, 10),
      };
      const next = [...scores, entry].sort((a, b) => b.score - a.score).slice(0, MAX_SCORES);
      const rank = next.indexOf(entry);
      setScores(next);
      save(next);
      return rank;
    },
    [scores],
  );

  return { scores, best, qualifies, addScore };
}
