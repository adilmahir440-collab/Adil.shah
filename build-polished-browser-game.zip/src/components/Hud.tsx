import { IconPause } from './icons';

interface Props {
  score: number;
  best: number;
  combo: number;
  multiplier: number;
  level: number;
  playing: boolean;
  onPause: () => void;
}

/** In-game heads-up display. Updates only on game events, never per frame. */
export function Hud({ score, best, combo, multiplier, level, playing, onPause }: Props) {
  const maxed = multiplier >= 8;
  const progress = maxed ? 100 : ((combo % 5) / 5) * 100;
  const beatingBest = score > 0 && score > best;

  return (
    <>
      {/* Top bar */}
      <div
        className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-3 px-4 sm:px-6"
        style={{ paddingTop: 'max(1rem, env(safe-area-inset-top))' }}
      >
        <div className="glass rounded-2xl px-3 py-1.5 sm:px-4 sm:py-2">
          <div className="font-display text-[9px] tracking-[0.3em] text-violet-300/80 sm:text-[10px]">SCORE</div>
          <div
            key={score}
            className="animate-bump origin-left font-display text-lg tabular-nums text-white sm:text-2xl"
          >
            {score.toLocaleString()}
          </div>
        </div>

        <div className="flex items-start gap-2">
          <div className="glass rounded-2xl px-3 py-1.5 text-right sm:px-4 sm:py-2">
            <div
              className={`font-display text-[9px] tracking-[0.3em] sm:text-[10px] ${
                beatingBest ? 'text-neon-gold' : 'text-violet-300/80'
              }`}
            >
              {beatingBest ? 'NEW BEST' : 'BEST'}
            </div>
            <div className="font-display text-lg tabular-nums text-violet-100 sm:text-2xl">
              {Math.max(best, score).toLocaleString()}
            </div>
          </div>
          {playing && (
            <button
              type="button"
              data-ui
              aria-label="Pause game"
              onClick={onPause}
              className="icon-btn glass pointer-events-auto touch-none"
            >
              <IconPause className="h-5 w-5" />
            </button>
          )}
        </div>
      </div>

      {/* Bottom bar: level + combo meter */}
      <div
        className="pointer-events-none absolute inset-x-0 bottom-0 flex justify-center px-4"
        style={{ paddingBottom: 'max(1.5rem, env(safe-area-inset-bottom))' }}
      >
        <div
          className={`glass flex items-center gap-3 rounded-full px-4 py-2 transition-opacity duration-300 ${
            combo > 0 || multiplier > 1 ? 'opacity-100' : 'opacity-60'
          }`}
        >
          <span className="font-display text-[10px] tracking-[0.25em] text-cyan-300">LV {level}</span>
          <span className="h-4 w-px bg-white/15" />
          <span className="font-display text-[10px] tracking-[0.25em] text-violet-200">COMBO</span>
          <span key={combo} className="animate-bump font-display text-base tabular-nums text-white">
            {combo}
          </span>
          <span className="font-display text-sm text-neon-gold">×{multiplier}</span>
          <div className="h-1.5 w-16 overflow-hidden rounded-full bg-white/10 sm:w-28">
            <div
              className="h-full rounded-full bg-gradient-to-r from-cyan-300 via-violet-400 to-fuchsia-400 transition-[width] duration-200 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>
    </>
  );
}
