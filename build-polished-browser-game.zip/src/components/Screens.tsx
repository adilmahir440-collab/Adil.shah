import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import type { ScoreEntry } from '../hooks/useHighScores';
import { HighScoreTable } from './HighScoreTable';
import { IconFlip, IconGem, IconSound, IconSpike } from './icons';

/* ------------------------------------------------------------------ */
/* Start screen                                                        */
/* ------------------------------------------------------------------ */

interface StartProps {
  scores: ScoreEntry[];
  muted: boolean;
  onPlay: () => void;
  onToggleMute: () => void;
}

export function StartScreen({ scores, muted, onPlay, onToggleMute }: StartProps) {
  return (
    <div className="touch-pan absolute inset-0 overflow-y-auto">
      <div className="flex min-h-full items-center justify-center p-4 py-8">
        <div className="glass animate-fade-up w-full max-w-md rounded-3xl p-6 text-center sm:p-8">
          <div className="font-display text-[11px] tracking-[0.5em] text-cyan-300/90">ARCADE · ONE BUTTON</div>
          <h1 className="neon-title mt-3 font-display text-5xl font-black leading-[0.95] tracking-tight sm:text-6xl">
            NEON
            <br />
            ORBIT
          </h1>
          <p className="mt-4 text-sm text-violet-100/75">
            Ride the ring. Catch the <span className="text-neon-gold">gold</span>. Dodge the{' '}
            <span className="text-neon-pink">red</span>.
          </p>

          <button type="button" autoFocus onClick={onPlay} className="btn-primary mt-7 w-full">
            Play
          </button>
          <p className="mt-3 text-xs text-violet-200/60">
            <span className="hidden sm:inline">Press Space · </span>
            <span className="animate-blink inline-block">Tap anywhere to start</span>
          </p>

          <ul className="mt-7 space-y-2 text-left text-sm">
            <HowRow icon={<IconFlip className="h-4 w-4" />} tone="cyan" title="Flip direction">
              Tap / click / Space / ↑ ↓ — or ← → to pick a side
            </HowRow>
            <HowRow icon={<IconGem className="h-3.5 w-3.5" />} tone="gold" title="Catch gold shards">
              Build combos for a score multiplier up to ×8
            </HowRow>
            <HowRow icon={<IconSpike className="h-4 w-4" />} tone="pink" title="Avoid red spikes">
              Graze one closely for a bonus — but one hit ends the run
            </HowRow>
          </ul>

          <div className="mt-7 text-left">
            <div className="mb-2 flex items-center justify-between">
              <h2 className="font-display text-[11px] tracking-[0.3em] text-violet-200">TOP SCORES</h2>
              <button
                type="button"
                data-ui
                aria-pressed={!muted}
                onClick={onToggleMute}
                className="flex items-center gap-1.5 text-[11px] font-display tracking-[0.2em] text-violet-200/80 hover:text-white"
              >
                <IconSound muted={muted} className="h-4 w-4" />
                {muted ? 'SOUND OFF' : 'SOUND ON'}
              </button>
            </div>
            <HighScoreTable scores={scores} limit={5} compact />
          </div>
        </div>
      </div>
    </div>
  );
}

const TONES = {
  cyan: 'bg-cyan-400/15 text-cyan-300 ring-cyan-400/40',
  gold: 'bg-yellow-300/15 text-yellow-300 ring-yellow-300/40',
  pink: 'bg-rose-400/15 text-rose-300 ring-rose-400/40',
} as const;

function HowRow({
  icon,
  tone,
  title,
  children,
}: {
  icon: ReactNode;
  tone: keyof typeof TONES;
  title: string;
  children: ReactNode;
}) {
  return (
    <li className="flex items-start gap-3 rounded-xl bg-white/[0.03] p-3">
      <span className={`mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg ring-1 ${TONES[tone]}`}>
        {icon}
      </span>
      <span>
        <span className="block font-display text-[11px] tracking-[0.15em] text-violet-50">{title}</span>
        <span className="block text-xs leading-relaxed text-violet-200/65">{children}</span>
      </span>
    </li>
  );
}

/* ------------------------------------------------------------------ */
/* Pause screen                                                        */
/* ------------------------------------------------------------------ */

interface PauseProps {
  muted: boolean;
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
  onToggleMute: () => void;
}

export function PauseScreen({ muted, onResume, onRestart, onMenu, onToggleMute }: PauseProps) {
  return (
    <div className="touch-pan absolute inset-0 grid place-items-center overflow-y-auto bg-[#03010a]/60 p-4 backdrop-blur-sm">
      <div className="glass animate-fade-up w-full max-w-xs rounded-3xl p-6 text-center">
        <div className="font-display text-[11px] tracking-[0.4em] text-cyan-300/90">GAME</div>
        <h2 className="neon-title mt-1 font-display text-4xl font-black tracking-tight">PAUSED</h2>
        <div className="mt-6 flex flex-col gap-3">
          <button type="button" autoFocus onClick={onResume} className="btn-primary w-full">
            Resume
          </button>
          <button type="button" onClick={onRestart} className="btn-ghost w-full">
            Restart
          </button>
          <button type="button" onClick={onMenu} className="btn-ghost w-full">
            Main menu
          </button>
          <button
            type="button"
            aria-pressed={!muted}
            onClick={onToggleMute}
            className="btn-ghost w-full"
          >
            <IconSound muted={muted} className="h-4 w-4" />
            Sound {muted ? 'off' : 'on'}
          </button>
        </div>
        <p className="mt-5 text-xs text-violet-200/55">P / Esc resume · R restart · M mute</p>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Game over screen                                                    */
/* ------------------------------------------------------------------ */

function useCountUp(target: number, duration = 800) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const k = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - k, 3);
      setValue(Math.round(target * eased));
      if (k < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return value;
}

interface OverProps {
  score: number;
  newBest: boolean;
  needsName: boolean;
  scores: ScoreEntry[];
  rank: number;
  onSave: (name: string) => void;
  onRetry: () => void;
  onMenu: () => void;
}

export function GameOverScreen({ score, newBest, needsName, scores, rank, onSave, onRetry, onMenu }: OverProps) {
  const shown = useCountUp(score);
  const [name, setName] = useState('');

  const submit = (e: FormEvent) => {
    e.preventDefault();
    onSave(name.trim() || 'CPU');
  };

  return (
    <div className="touch-pan absolute inset-0 overflow-y-auto bg-[#03010a]/65 backdrop-blur-sm">
      <div className="flex min-h-full items-center justify-center p-4 py-8">
        <div className="glass animate-fade-up w-full max-w-sm rounded-3xl p-6 text-center">
          <div className="font-display text-[11px] tracking-[0.4em] text-rose-300/90">SIGNAL LOST</div>
          <h2 className="mt-1 font-display text-4xl font-black tracking-tight text-rose-100 drop-shadow-[0_0_18px_rgba(251,113,133,0.55)]">
            GAME OVER
          </h2>

          <div className="mt-5">
            <div className="font-display text-[10px] tracking-[0.3em] text-violet-300/80">FINAL SCORE</div>
            <div className="font-display text-5xl font-black tabular-nums text-white">{shown.toLocaleString()}</div>
            {newBest && (
              <div className="animate-bump mt-2 inline-block rounded-full bg-yellow-300/15 px-3 py-1 font-display text-[10px] tracking-[0.25em] text-neon-gold ring-1 ring-yellow-300/40">
                ★ NEW HIGH SCORE ★
              </div>
            )}
          </div>

          {needsName ? (
            <form onSubmit={submit} className="mt-6 space-y-3" data-ui>
              <label htmlFor="initials" className="block font-display text-[11px] tracking-[0.3em] text-cyan-200">
                ENTER YOUR INITIALS
              </label>
              <div className="flex gap-2">
                <input
                  id="initials"
                  autoFocus
                  autoComplete="off"
                  maxLength={3}
                  value={name}
                  placeholder="AAA"
                  onChange={(e) => setName(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''))}
                  className="min-w-0 flex-1 rounded-xl border border-cyan-400/40 bg-black/40 px-4 py-3 text-center font-display text-2xl tracking-[0.5em] text-white placeholder:text-white/20 focus:border-cyan-300 focus:outline-none focus:ring-2 focus:ring-cyan-400/40"
                />
                <button type="submit" className="btn-primary px-6">
                  Save
                </button>
              </div>
            </form>
          ) : (
            <div className="animate-late-in mt-6 flex flex-col gap-3">
              <button type="button" autoFocus onClick={onRetry} className="btn-primary w-full">
                Play again
              </button>
              <button type="button" onClick={onMenu} className="btn-ghost w-full">
                Main menu
              </button>
              <p className="text-xs text-violet-200/60">
                <span className="hidden sm:inline">Press Space or R · </span>instant restart
              </p>
            </div>
          )}

          <div className="mt-7 text-left">
            <h3 className="mb-3 text-center font-display text-[11px] tracking-[0.3em] text-violet-200">HIGH SCORES</h3>
            <HighScoreTable scores={scores} highlight={rank} />
          </div>
        </div>
      </div>
    </div>
  );
}
