import type { ScoreEntry } from '../hooks/useHighScores';

interface Props {
  scores: ScoreEntry[];
  limit?: number;
  /** Index of the row to spotlight (e.g. a just-saved score), or -1. */
  highlight?: number;
  compact?: boolean;
}

export function HighScoreTable({ scores, limit = 10, highlight = -1, compact = false }: Props) {
  const rows = scores.slice(0, limit);

  if (rows.length === 0) {
    return (
      <p className="py-4 text-center text-sm text-violet-200/60">
        No scores yet — be the first on the board.
      </p>
    );
  }

  return (
    <ol className="space-y-1.5">
      {rows.map((s, i) => {
        const isHi = i === highlight;
        return (
          <li
            key={`${i}-${s.date}-${s.score}`}
            className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
              isHi
                ? 'animate-row-in bg-cyan-400/15 ring-1 ring-cyan-300/70 shadow-[0_0_18px_rgba(34,211,238,0.35)]'
                : 'bg-white/[0.035]'
            }`}
          >
            <span
              className={`w-7 font-display text-[11px] tabular-nums ${
                i === 0 ? 'text-neon-gold' : i < 3 ? 'text-violet-200' : 'text-violet-300/50'
              }`}
            >
              {String(i + 1).padStart(2, '0')}
            </span>
            <span className="font-display tracking-[0.25em] text-violet-50">{s.name}</span>
            <span className="ml-auto font-display tabular-nums text-cyan-200">
              {s.score.toLocaleString()}
            </span>
            {!compact && <span className="hidden text-xs text-violet-300/50 sm:inline">{s.date}</span>}
          </li>
        );
      })}
    </ol>
  );
}
