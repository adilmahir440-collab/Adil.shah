import { Sfx } from './audio';

/**
 * NEON ORBIT — core engine.
 * A single player rides a glowing ring. Tap / Space flips direction.
 * Gold shards (gems) must be caught as they cross the ring; red shards must be avoided.
 * Everything runs on a canvas loop outside React for smooth 60fps.
 */

export type Phase = 'menu' | 'playing' | 'paused' | 'dying' | 'over';

export interface Snapshot {
  phase: Phase;
  score: number;
  combo: number;
  multiplier: number;
  level: number;
  muted: boolean;
}

export interface EngineCallbacks {
  onChange: (s: Snapshot) => void;
  onGameOver: (score: number, time: number) => void;
}

interface Hazard { a: number; d: number; crossed: boolean }
interface Gem { a: number; d: number; spin: number }
interface Particle { x: number; y: number; vx: number; vy: number; life: number; max: number; size: number; color: string; drag: number }
interface Shock { x: number; y: number; r: number; vr: number; life: number; max: number; color: string; width: number }
interface Pop { x: number; y: number; vy: number; text: string; life: number; max: number; color: string; size: number }
interface Star { a: number; r: number; s: number; b: number }
interface TrailPt { a: number; life: number }

const TAU = Math.PI * 2;
/** Angular hit window (radians) for hazards. */
const HIT = 0.12;
/** Angular window for near-miss "graze" bonus. */
const GRAZE = 0.3;
/** Angular catch window for gems. */
const CATCH = 0.2;
const PLAYER_R = 7;
const MAX_PARTICLES = 280;
const TRAIL_LIFE = 0.3;
const MAX_MULT = 8;

/** RGB triplets so we can compose alpha at will. */
const C = {
  ring: '34,211,238',
  hazard: '251,113,133',
  gem: '253,224,71',
  white: '255,255,255',
  player: '245,243,255',
  violet: '167,139,250',
  grey: '148,163,184',
  graze: '103,232,249',
};

const wrap = (a: number) => {
  a %= TAU;
  if (a > Math.PI) a -= TAU;
  else if (a < -Math.PI) a += TAU;
  return a;
};
const angDiff = (a: number, b: number) => Math.abs(wrap(a - b));
const rnd = (a: number, b: number) => a + Math.random() * (b - a);

export class OrbitEngine {
  phase: Phase = 'menu';
  readonly sfx = new Sfx();
  private cb: EngineCallbacks;

  // canvas + layout
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private bg: HTMLCanvasElement | null = null;
  private w = 0;
  private h = 0;
  private dpr = 1;
  private cx = 0;
  private cy = 0;
  private R = 100; // ring radius (px)
  private u = 1; // unit scale (px per design unit)
  private outer = 400; // spawn distance (px)

  // simulation state
  private now = 0; // real seconds (for visuals)
  private t = 0; // play seconds
  private score = 0;
  private combo = 0;
  private multiplier = 1;
  private level = 1;
  private spawnCount = 0;
  private spawnT = 0.6;
  private deathT = 0;
  private overReadyAt = 0;
  private locked = false;

  private p = { a: -Math.PI / 2, dir: 1 as 1 | -1, flip: 0, alive: true, omega: 2.2 };
  private ptr = { id: -1, x: 0, y: 0 };
  private menuFlipAt = 0;
  private trail: TrailPt[] = [];
  private hazards: Hazard[] = [];
  private gems: Gem[] = [];
  private parts: Particle[] = [];
  private shocks: Shock[] = [];
  private pops: Pop[] = [];
  private stars: Star[] = [];

  // juice
  private shake = 0;
  private sx = 0;
  private sy = 0;
  private flash = 0;
  private flashRGB = '255,60,90';
  private pulse = 0;

  private raf = 0;
  private last = 0;

  constructor(cb: EngineCallbacks) {
    this.cb = cb;
  }

  /* ------------------------------------------------------------------ */
  /* Lifecycle                                                           */
  /* ------------------------------------------------------------------ */

  attach(canvas: HTMLCanvasElement): () => void {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    const parent = canvas.parentElement;
    const ro = new ResizeObserver(() => this.measure());
    if (parent) ro.observe(parent);

    const onKey = (e: KeyboardEvent) => this.handleKey(e);
    const onDown = (e: PointerEvent) => this.handlePointerDown(e);
    const onUp = (e: PointerEvent) => this.handlePointerUp(e);
    const onCancel = () => (this.ptr.id = -1);
    const onBlur = () => this.autoPause();
    const onVis = () => {
      if (document.hidden) this.autoPause();
    };
    window.addEventListener('keydown', onKey);
    window.addEventListener('pointerdown', onDown);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onCancel);
    window.addEventListener('blur', onBlur);
    document.addEventListener('visibilitychange', onVis);

    this.measure();
    this.last = 0;
    this.raf = requestAnimationFrame(this.frame);

    return () => {
      cancelAnimationFrame(this.raf);
      ro.disconnect();
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('pointerdown', onDown);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onCancel);
      window.removeEventListener('blur', onBlur);
      document.removeEventListener('visibilitychange', onVis);
    };
  }

  private frame = (ts: number) => {
    const dt = this.last ? Math.min(0.05, (ts - this.last) / 1000) : 0.016;
    this.last = ts;
    this.update(dt);
    this.render();
    this.raf = requestAnimationFrame(this.frame);
  };

  /* ------------------------------------------------------------------ */
  /* Public controls (used by React UI)                                  */
  /* ------------------------------------------------------------------ */

  startGame() {
    this.sfx.ensure();
    this.reset();
    this.phase = 'playing';
    this.sfx.play('start');
    this.shocks.push({ x: this.cx, y: this.cy, r: this.R, vr: 260 * this.u, life: 0.5, max: 0.5, color: C.ring, width: 4 });
    this.emit();
  }

  restart() {
    if (this.phase === 'over' && (this.now < this.overReadyAt || this.locked)) return;
    this.startGame();
  }

  toMenu() {
    this.reset();
    this.phase = 'menu';
    this.menuFlipAt = 0;
    this.emit();
  }

  togglePause() {
    if (this.phase === 'playing') {
      this.phase = 'paused';
      this.emit();
    } else if (this.phase === 'paused') {
      this.resume();
    }
  }

  resume() {
    if (this.phase !== 'paused') return;
    this.sfx.ensure();
    this.phase = 'playing';
    this.emit();
  }

  /** Locks restart input (used while the player is typing their name). */
  setLocked(v: boolean) {
    this.locked = v;
  }

  toggleMute() {
    this.sfx.setMuted(!this.sfx.muted);
    this.emit();
  }

  /* ------------------------------------------------------------------ */
  /* Input                                                               */
  /* ------------------------------------------------------------------ */

  private handleKey(e: KeyboardEvent) {
    const t = e.target as HTMLElement | null;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
    const code = e.code;
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(code)) e.preventDefault();
    // Let focused buttons handle their own Space/Enter activation.
    if ((code === 'Space' || code === 'Enter') && t && t.tagName === 'BUTTON') return;
    if (e.repeat) return;

    switch (code) {
      case 'Space':
      case 'ArrowUp':
      case 'ArrowDown':
      case 'KeyW':
      case 'KeyS':
      case 'Enter':
        this.action();
        break;
      case 'ArrowLeft':
      case 'KeyA':
        this.setDir(-1);
        break;
      case 'ArrowRight':
      case 'KeyD':
        this.setDir(1);
        break;
      case 'KeyP':
      case 'Escape':
        this.togglePause();
        break;
      case 'KeyR':
        this.restart();
        break;
      case 'KeyM':
        this.toggleMute();
        break;
    }
  }

  private isUiTarget(e: PointerEvent) {
    const t = e.target as HTMLElement | null;
    return !!t && !!t.closest('button, input, textarea, a, select, label, form, [data-ui]');
  }

  /** Playing: flip instantly on press for tight touch response. */
  private handlePointerDown(e: PointerEvent) {
    if (e.button > 0 || this.isUiTarget(e)) return;
    this.sfx.ensure();
    this.ptr = { id: e.pointerId, x: e.clientX, y: e.clientY };
    if (this.phase === 'playing') this.flip();
  }

  /**
   * Menus: resolve taps on release, so scrolling a long score list
   * never accidentally starts / resumes the game.
   */
  private handlePointerUp(e: PointerEvent) {
    if (e.pointerId !== this.ptr.id) return;
    this.ptr.id = -1;
    if (this.isUiTarget(e)) return;
    if (Math.hypot(e.clientX - this.ptr.x, e.clientY - this.ptr.y) > 12) return;
    // Game-over never restarts from a generic tap – only from its buttons / keys.
    if (this.phase === 'playing' || this.phase === 'over') return;
    this.action();
  }

  /** Primary action: start / flip / resume / restart depending on phase. */
  private action() {
    switch (this.phase) {
      case 'menu':
        this.startGame();
        break;
      case 'playing':
        this.flip();
        break;
      case 'paused':
        this.resume();
        break;
      case 'over':
        this.restart();
        break;
    }
  }

  private flip() {
    if (this.phase !== 'playing' || !this.p.alive) return;
    this.p.dir = this.p.dir === 1 ? -1 : 1;
    this.p.flip = 1;
    const pt = this.pos(this.p.a, this.R);
    this.burst(pt.x, pt.y, C.ring, 7, 150, 0.3, 0.05);
    this.sfx.play('flip');
  }

  private setDir(d: 1 | -1) {
    if (this.phase !== 'playing' || !this.p.alive || this.p.dir === d) return;
    this.p.dir = d;
    this.p.flip = 1;
    const pt = this.pos(this.p.a, this.R);
    this.burst(pt.x, pt.y, C.ring, 7, 150, 0.3, 0.05);
    this.sfx.play('flip');
  }

  private autoPause() {
    if (this.phase === 'playing') {
      this.phase = 'paused';
      this.emit();
    }
  }

  /* ------------------------------------------------------------------ */
  /* Layout                                                              */
  /* ------------------------------------------------------------------ */

  private measure() {
    if (!this.canvas || !this.canvas.parentElement) return;
    const parent = this.canvas.parentElement;
    const w = Math.max(1, parent.clientWidth);
    const h = Math.max(1, parent.clientHeight);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (w === this.w && h === this.h && dpr === this.dpr) return;
    this.w = w;
    this.h = h;
    this.dpr = dpr;
    this.canvas.width = Math.round(w * dpr);
    this.canvas.height = Math.round(h * dpr);
    this.cx = w / 2;
    this.cy = h / 2;
    const m = Math.min(w, h);
    this.u = m / 420;
    this.R = Math.min(m * 0.28, 170);
    this.outer = Math.hypot(w, h) / 2 + 30;
    this.buildBackground();
    if (this.stars.length === 0) this.initStars();
  }

  private buildBackground() {
    const { w, h, dpr, cx, cy, R } = this;
    const c = document.createElement('canvas');
    c.width = Math.round(w * dpr);
    c.height = Math.round(h * dpr);
    const g = c.getContext('2d');
    if (!g) return;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.fillStyle = '#03010a';
    g.fillRect(0, 0, w, h);

    const grad = g.createRadialGradient(cx, cy, 0, cx, cy, Math.max(w, h) * 0.75);
    grad.addColorStop(0, '#1d1046');
    grad.addColorStop(0.45, '#0c0626');
    grad.addColorStop(1, '#03010a');
    g.fillStyle = grad;
    g.fillRect(0, 0, w, h);

    // soft nebula blobs
    const blob = (x: number, y: number, r: number, rgb: string, a: number) => {
      const b = g.createRadialGradient(x, y, 0, x, y, r);
      b.addColorStop(0, `rgba(${rgb},${a})`);
      b.addColorStop(1, `rgba(${rgb},0)`);
      g.fillStyle = b;
      g.fillRect(0, 0, w, h);
    };
    blob(cx - R * 1.4, cy - R * 0.9, R * 2.2, '217,70,239', 0.09);
    blob(cx + R * 1.6, cy + R * 1.1, R * 2.4, '34,211,238', 0.07);

    // vignette
    const vg = g.createRadialGradient(cx, cy, Math.min(w, h) * 0.35, cx, cy, Math.max(w, h) * 0.75);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(0,0,0,0.7)');
    g.fillStyle = vg;
    g.fillRect(0, 0, w, h);
    this.bg = c;
  }

  private initStars() {
    this.stars = [];
    for (let i = 0; i < 170; i++) {
      this.stars.push({
        a: Math.random() * TAU,
        r: Math.random() * this.outer,
        s: rnd(0.3, 1),
        b: rnd(0.35, 1),
      });
    }
  }

  /* ------------------------------------------------------------------ */
  /* Simulation                                                          */
  /* ------------------------------------------------------------------ */

  private reset() {
    this.t = 0;
    this.score = 0;
    this.combo = 0;
    this.multiplier = 1;
    this.level = 1;
    this.spawnCount = 0;
    this.spawnT = 0.6;
    this.deathT = 0;
    this.p = { a: -Math.PI / 2, dir: 1, flip: 0, alive: true, omega: 2.2 };
    this.trail = [];
    this.hazards = [];
    this.gems = [];
    this.parts = [];
    this.shocks = [];
    this.pops = [];
    this.shake = 0;
    this.flash = 0;
    this.pulse = 0;
  }

  /** Hazard travel time (s) from spawn to ring – shrinks over time = difficulty ramp. */
  private travelTime() {
    return Math.max(0.7, 1.35 - this.t * 0.01);
  }

  private update(dt: number) {
    if (this.phase === 'paused') return;
    this.now += dt;
    this.updateFx(dt);
    this.updateStars(dt);

    switch (this.phase) {
      case 'menu':
        this.updateMenu(dt);
        break;
      case 'playing':
        this.simulate(dt, true);
        break;
      case 'dying':
        // Slow-motion aftermath before the game-over screen.
        this.simulate(dt * 0.3, false);
        this.deathT -= dt;
        if (this.deathT <= 0) {
          this.phase = 'over';
          this.overReadyAt = this.now + 0.6;
          this.cb.onGameOver(this.score, this.t);
          this.emit();
        }
        break;
      default:
        break;
    }

    if (this.p.alive && (this.phase === 'menu' || this.phase === 'playing')) {
      this.trail.push({ a: this.p.a, life: TRAIL_LIFE });
      if (this.trail.length > 28) this.trail.shift();
    }
  }

  private updateMenu(dt: number) {
    const p = this.p;
    if (this.now > this.menuFlipAt) {
      p.dir = p.dir === 1 ? -1 : 1;
      p.flip = 1;
      this.menuFlipAt = this.now + rnd(1.4, 2.6);
    }
    p.omega = 1.5;
    p.a = wrap(p.a + p.dir * p.omega * dt);
  }

  private simulate(dt: number, live: boolean) {
    const p = this.p;
    if (live) {
      this.t += dt;
      const lvl = 1 + Math.floor(this.t / 15);
      if (lvl !== this.level) {
        this.level = lvl;
        this.onLevelUp();
        this.emit();
      }
      p.omega = 2.2 + Math.min(2.4, this.t * 0.03);
      p.a = wrap(p.a + p.dir * p.omega * dt);

      this.spawnT -= dt;
      if (this.spawnT <= 0) {
        this.spawn();
        this.spawnT = Math.max(0.36, 1.1 - this.t * 0.01) * rnd(0.85, 1.15);
      }
    }

    const R = this.R;
    const speed = (this.outer - R) / this.travelTime();

    for (let i = this.hazards.length - 1; i >= 0; i--) {
      const h = this.hazards[i];
      h.d -= speed * dt;
      if (!h.crossed && h.d <= R) {
        h.crossed = true;
        if (live && this.phase === 'playing') {
          const diff = angDiff(h.a, p.a);
          if (diff < HIT) this.die();
          else if (diff < GRAZE) this.graze(h.a);
        }
      }
      if (h.d < R * 0.3) {
        const sp = this.pos(h.a, R * 0.3);
        this.burst(sp.x, sp.y, C.hazard, 6, 120, 0.4, 0.1);
        this.hazards.splice(i, 1);
      }
    }

    for (let i = this.gems.length - 1; i >= 0; i--) {
      const g = this.gems[i];
      g.d -= speed * dt;
      g.spin += dt * 3.5;
      if (g.d <= R) {
        if (live && this.phase === 'playing') {
          if (angDiff(g.a, p.a) < CATCH) this.collect(g.a);
          else this.miss(g.a);
        }
        this.gems.splice(i, 1);
      }
    }
  }

  private spawn() {
    const p = this.p;
    this.spawnCount++;
    const T = this.travelTime();
    const speed = (this.outer - this.R) / T;
    const forceGem = this.spawnCount <= 2; // friendly opening

    if (forceGem || Math.random() < 0.4) {
      if (forceGem || Math.random() < 0.25) {
        // Gem streak spaced in *time*, so a steady sweep in the orb's
        // current direction collects the whole chain.
        const S = 0.2;
        for (let i = 0; i < 3; i++) {
          this.gems.push({
            a: wrap(p.a + p.dir * p.omega * (T + i * S)),
            d: this.outer + speed * S * i,
            spin: Math.random() * TAU,
          });
        }
      } else {
        // Single gem placed where the orb will be when it arrives (± an offset),
        // so catching it requires reading the orbit, not luck.
        this.gems.push({
          a: wrap(p.a + p.dir * p.omega * T + rnd(-0.7, 0.7)),
          d: this.outer,
          spin: Math.random() * TAU,
        });
      }
      return;
    }

    const burst = this.t > 18 && Math.random() < 0.2;
    let a = Math.random() * TAU;
    let guard = 0;
    while (angDiff(a, p.a) < 0.3 && guard++ < 10) a = Math.random() * TAU;
    this.hazards.push({ a, d: this.outer, crossed: false });
    if (burst) {
      // Opposite-side shard forces a direction flip.
      this.hazards.push({ a: wrap(a + Math.PI + rnd(-0.35, 0.35)), d: this.outer + 18 * this.u, crossed: false });
    }
  }

  private refreshMult() {
    this.multiplier = Math.min(MAX_MULT, 1 + Math.floor(this.combo / 5));
  }

  private collect(a: number) {
    this.combo++;
    this.refreshMult();
    const gain = 10 * this.multiplier;
    this.score += gain;
    const pt = this.pos(a, this.R);
    this.burst(pt.x, pt.y, C.gem, 18, 300, 0.6);
    this.burst(pt.x, pt.y, C.white, 6, 160, 0.35);
    this.shocks.push({ x: pt.x, y: pt.y, r: 4 * this.u, vr: 200 * this.u, life: 0.35, max: 0.35, color: C.gem, width: 2.5 });
    this.pops.push({ x: pt.x, y: pt.y - 14 * this.u, vy: -60 * this.u, text: `+${gain}`, life: 0.9, max: 0.9, color: C.gem, size: 20 });
    this.shake = Math.max(this.shake, 2.5);
    this.sfx.play('collect', this.combo);
    if (this.combo % 5 === 0) this.milestone();
    this.emit();
  }

  private graze(a: number) {
    this.combo++;
    this.refreshMult();
    const gain = 5 * this.multiplier;
    this.score += gain;
    const pt = this.pos(a, this.R);
    this.burst(pt.x, pt.y, C.graze, 12, 240, 0.45);
    this.shocks.push({ x: pt.x, y: pt.y, r: 3 * this.u, vr: 150 * this.u, life: 0.3, max: 0.3, color: C.graze, width: 2 });
    this.pops.push({ x: pt.x, y: pt.y - 16 * this.u, vy: -70 * this.u, text: `CLOSE +${gain}`, life: 0.8, max: 0.8, color: C.graze, size: 14 });
    this.shake = Math.max(this.shake, 1.5);
    this.sfx.play('graze');
    if (this.combo % 5 === 0) this.milestone();
    this.emit();
  }

  private miss(a: number) {
    const lost = this.combo;
    this.combo = 0;
    this.multiplier = 1;
    const pt = this.pos(a, this.R);
    this.burst(pt.x, pt.y, C.grey, 8, 120, 0.4, 0.1);
    if (lost > 0) {
      this.pops.push({ x: this.cx, y: this.cy + this.R * 0.55, vy: -20 * this.u, text: 'COMBO LOST', life: 0.9, max: 0.9, color: C.grey, size: 13 });
    }
    this.sfx.play('miss');
    this.emit();
  }

  private milestone() {
    this.pops.push({ x: this.cx, y: this.cy - this.R * 0.35, vy: -30 * this.u, text: `${this.combo} COMBO`, life: 0.9, max: 0.9, color: C.violet, size: 24 });
    this.shocks.push({ x: this.cx, y: this.cy, r: this.R * 0.5, vr: 380 * this.u, life: 0.55, max: 0.55, color: C.violet, width: 4 });
    this.flashRGB = C.violet;
    this.flash = Math.max(this.flash, 0.18);
    this.shake = Math.max(this.shake, 5);
    this.sfx.play('combo');
  }

  private onLevelUp() {
    this.pops.push({ x: this.cx, y: this.cy, vy: -10 * this.u, text: `LEVEL ${this.level}`, life: 1.4, max: 1.4, color: C.violet, size: 30 });
    this.shocks.push({ x: this.cx, y: this.cy, r: this.R * 0.9, vr: 320 * this.u, life: 0.8, max: 0.8, color: C.violet, width: 3 });
    this.shake = Math.max(this.shake, 4);
    this.sfx.play('level');
  }

  private die() {
    if (this.phase !== 'playing') return;
    this.phase = 'dying';
    this.deathT = 0.9;
    this.p.alive = false;
    const pt = this.pos(this.p.a, this.R);
    this.burst(pt.x, pt.y, C.player, 28, 420, 0.8);
    this.burst(pt.x, pt.y, C.hazard, 40, 360, 0.9);
    this.shocks.push({ x: pt.x, y: pt.y, r: 6 * this.u, vr: 520 * this.u, life: 0.6, max: 0.6, color: C.hazard, width: 6 });
    this.shocks.push({ x: this.cx, y: this.cy, r: this.R, vr: 280 * this.u, life: 0.7, max: 0.7, color: C.hazard, width: 3 });
    this.shake = 18;
    this.flashRGB = '255,60,90';
    this.flash = 1;
    this.sfx.play('death');
    this.emit();
  }

  private updateStars(dt: number) {
    const moving = this.phase === 'playing' || this.phase === 'dying';
    const warp = moving ? ((this.outer - this.R) / this.travelTime()) * 0.1 : 0;
    for (const s of this.stars) {
      s.r += (8 * this.u + warp) * s.s * dt;
      if (s.r > this.outer) {
        s.r = rnd(0, this.R * 0.6);
        s.a = Math.random() * TAU;
      }
    }
  }

  private updateFx(dt: number) {
    this.shake *= Math.exp(-dt * 10);
    this.sx = (Math.random() * 2 - 1) * this.shake;
    this.sy = (Math.random() * 2 - 1) * this.shake;
    this.flash *= Math.exp(-dt * 5);
    this.pulse = Math.pow(Math.max(0, Math.sin(this.now * 4.2)), 10);
    this.p.flip *= Math.exp(-dt * 14);

    for (let i = this.parts.length - 1; i >= 0; i--) {
      const q = this.parts[i];
      q.life -= dt;
      if (q.life <= 0) {
        this.parts.splice(i, 1);
        continue;
      }
      q.x += q.vx * dt;
      q.y += q.vy * dt;
      const k = Math.pow(q.drag, dt);
      q.vx *= k;
      q.vy *= k;
    }
    for (let i = this.shocks.length - 1; i >= 0; i--) {
      const s = this.shocks[i];
      s.life -= dt;
      if (s.life <= 0) {
        this.shocks.splice(i, 1);
        continue;
      }
      s.r += s.vr * dt;
      s.vr *= Math.exp(-dt * 3.2);
    }
    for (let i = this.pops.length - 1; i >= 0; i--) {
      const q = this.pops[i];
      q.life -= dt;
      if (q.life <= 0) {
        this.pops.splice(i, 1);
        continue;
      }
      q.y += q.vy * dt;
      q.vy *= Math.exp(-dt * 3);
    }
    for (let i = this.trail.length - 1; i >= 0; i--) {
      this.trail[i].life -= dt;
      if (this.trail[i].life <= 0) this.trail.splice(i, 1);
    }
  }

  private burst(x: number, y: number, color: string, n: number, speed: number, life: number, drag = 0.03) {
    for (let i = 0; i < n && this.parts.length < MAX_PARTICLES; i++) {
      const ang = Math.random() * TAU;
      const sp = speed * this.u * (0.35 + Math.random() * 0.65);
      this.parts.push({
        x,
        y,
        vx: Math.cos(ang) * sp,
        vy: Math.sin(ang) * sp,
        life: life * (0.6 + Math.random() * 0.4),
        max: life,
        size: (1.6 + Math.random() * 2.2) * this.u,
        color,
        drag,
      });
    }
  }

  private pos(a: number, d: number) {
    return { x: this.cx + Math.cos(a) * d, y: this.cy + Math.sin(a) * d };
  }

  private emit() {
    this.cb.onChange({
      phase: this.phase,
      score: this.score,
      combo: this.combo,
      multiplier: this.multiplier,
      level: this.level,
      muted: this.sfx.muted,
    });
  }

  /* ------------------------------------------------------------------ */
  /* Rendering                                                           */
  /* ------------------------------------------------------------------ */

  private render() {
    const ctx = this.ctx;
    if (!ctx || !this.canvas || !this.w) return;
    const { w, h, dpr } = this;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 1;

    ctx.save();
    ctx.translate(this.sx, this.sy);
    ctx.fillStyle = '#03010a';
    ctx.fillRect(-20, -20, w + 40, h + 40);
    if (this.bg) ctx.drawImage(this.bg, -20, -20, w + 40, h + 40);

    this.drawStars(ctx);
    this.drawTelegraphs(ctx);
    this.drawCore(ctx);
    this.drawRing(ctx);
    this.drawTrail(ctx);
    this.drawGems(ctx);
    this.drawHazards(ctx);
    this.drawPlayer(ctx);
    this.drawShocks(ctx);
    this.drawParticles(ctx);
    this.drawPops(ctx);
    ctx.restore();

    if (this.flash > 0.01) {
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = `rgba(${this.flashRGB},${(this.flash * 0.35).toFixed(3)})`;
      ctx.fillRect(0, 0, w, h);
      ctx.globalCompositeOperation = 'source-over';
    }
  }

  private drawStars(ctx: CanvasRenderingContext2D) {
    const moving = this.phase === 'playing' || this.phase === 'dying';
    const warp = moving ? ((this.outer - this.R) / this.travelTime()) * 0.1 : 0;
    ctx.lineCap = 'round';
    for (const s of this.stars) {
      const x = this.cx + Math.cos(s.a) * s.r;
      const y = this.cy + Math.sin(s.a) * s.r;
      const k = Math.min(1, s.r / (this.R * 1.4));
      const alpha = s.b * (0.25 + 0.75 * k);
      const len = Math.min(16 * this.u, warp * s.s * 0.06);
      ctx.strokeStyle = `rgba(224,231,255,${alpha.toFixed(3)})`;
      ctx.lineWidth = (0.6 + s.s * 1.1) * this.u;
      if (len > 1.5) {
        const x0 = this.cx + Math.cos(s.a) * (s.r - len);
        const y0 = this.cy + Math.sin(s.a) * (s.r - len);
        ctx.beginPath();
        ctx.moveTo(x0, y0);
        ctx.lineTo(x, y);
        ctx.stroke();
      } else {
        ctx.fillStyle = `rgba(224,231,255,${alpha.toFixed(3)})`;
        ctx.beginPath();
        ctx.arc(x, y, (0.6 + s.s * 1.1) * this.u, 0, TAU);
        ctx.fill();
      }
    }
  }

  /** Lanes + landing markers so incoming shards are readable at a glance. */
  private drawTelegraphs(ctx: CanvasRenderingContext2D) {
    const R = this.R;
    const reach = 170 * this.u;
    ctx.lineCap = 'round';
    for (const h of this.hazards) {
      if (h.crossed) continue;
      const dist = h.d - R;
      const k = Math.max(0, Math.min(1, 1 - dist / reach));
      const from = this.pos(h.a, this.outer);
      const to = this.pos(h.a, R);
      ctx.strokeStyle = `rgba(${C.hazard},0.07)`;
      ctx.lineWidth = 1 * this.u;
      ctx.beginPath();
      ctx.moveTo(from.x, from.y);
      ctx.lineTo(to.x, to.y);
      ctx.stroke();
      if (k > 0) {
        ctx.strokeStyle = `rgba(${C.hazard},${(0.2 + 0.7 * k).toFixed(3)})`;
        ctx.lineWidth = 5 * this.u;
        ctx.beginPath();
        ctx.arc(this.cx, this.cy, R, h.a - HIT, h.a + HIT);
        ctx.stroke();
      }
    }
    for (const g of this.gems) {
      const dist = g.d - R;
      const k = Math.max(0, Math.min(1, 1 - dist / reach));
      if (k <= 0) continue;
      ctx.strokeStyle = `rgba(${C.gem},${(0.15 + 0.5 * k).toFixed(3)})`;
      ctx.lineWidth = 3 * this.u;
      ctx.beginPath();
      ctx.arc(this.cx, this.cy, R, g.a - CATCH, g.a + CATCH);
      ctx.stroke();
    }
  }

  private drawCore(ctx: CanvasRenderingContext2D) {
    const { cx, cy, R, u } = this;
    const cr = R * 0.42 * (1 + this.pulse * 0.05);
    const boost = 0.6 + this.multiplier * 0.06;
    ctx.globalCompositeOperation = 'lighter';
    const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, cr * 1.4);
    g.addColorStop(0, `rgba(${C.violet},${(0.28 * boost).toFixed(3)})`);
    g.addColorStop(0.55, `rgba(88,28,135,${(0.12 * boost).toFixed(3)})`);
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(cx, cy, cr * 1.4, 0, TAU);
    ctx.fill();
    ctx.globalCompositeOperation = 'source-over';

    // rotating sigil
    ctx.strokeStyle = `rgba(${C.violet},0.45)`;
    ctx.lineWidth = 1.5 * u;
    ctx.beginPath();
    for (let k = 0; k < 3; k++) {
      const a = this.now * 0.6 + (k * TAU) / 3;
      const x = cx + Math.cos(a) * cr * 0.35;
      const y = cy + Math.sin(a) * cr * 0.35;
      if (k === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.stroke();
  }

  private drawRing(ctx: CanvasRenderingContext2D) {
    const { cx, cy, u } = this;
    const r = this.R + this.pulse * 4 * u;
    ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = `rgba(${C.ring},0.09)`;
    ctx.lineWidth = 34 * u;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, TAU);
    ctx.stroke();
    ctx.strokeStyle = `rgba(${C.ring},0.22)`;
    ctx.lineWidth = 10 * u;
    ctx.stroke();
    ctx.globalCompositeOperation = 'source-over';
    ctx.strokeStyle = `rgba(${C.ring},1)`;
    ctx.lineWidth = 2.5 * u;
    ctx.stroke();

    // orbital ticks that spin, selling motion
    ctx.beginPath();
    for (let i = 0; i < 48; i++) {
      const a = (i * TAU) / 48 + this.now * 0.12;
      const r0 = this.R + 14 * u;
      const r1 = this.R + (i % 4 === 0 ? 24 : 19) * u;
      ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
      ctx.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1);
    }
    ctx.strokeStyle = `rgba(${C.ring},0.35)`;
    ctx.lineWidth = 1.5 * u;
    ctx.stroke();
  }

  private drawTrail(ctx: CanvasRenderingContext2D) {
    const tr = this.trail;
    if (tr.length < 2) return;
    ctx.lineCap = 'round';
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 1; i < tr.length; i++) {
      const prev = tr[i - 1];
      const cur = tr[i];
      const k = Math.max(0, cur.life / TRAIL_LIFE);
      const delta = wrap(cur.a - prev.a);
      ctx.strokeStyle = `rgba(${C.ring},${(k * 0.6).toFixed(3)})`;
      ctx.lineWidth = (2 + 5 * k) * this.u;
      ctx.beginPath();
      ctx.arc(this.cx, this.cy, this.R, prev.a, prev.a + delta, delta < 0);
      ctx.stroke();
    }
    ctx.globalCompositeOperation = 'source-over';
  }

  private diamond(ctx: CanvasRenderingContext2D, s: number) {
    ctx.beginPath();
    ctx.moveTo(0, -s);
    ctx.lineTo(s * 0.7, 0);
    ctx.lineTo(0, s);
    ctx.lineTo(-s * 0.7, 0);
    ctx.closePath();
  }

  private drawGems(ctx: CanvasRenderingContext2D) {
    for (const g of this.gems) {
      const sc = Math.min(1, (this.outer - g.d) / (80 * this.u));
      if (sc <= 0.02) continue;
      const { x, y } = this.pos(g.a, g.d);
      const s = 9 * this.u * sc;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(g.spin);
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = `rgba(${C.gem},0.22)`;
      this.diamond(ctx, s * 2.1);
      ctx.fill();
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = `rgb(${C.gem})`;
      this.diamond(ctx, s);
      ctx.fill();
      ctx.fillStyle = '#fffbeb';
      this.diamond(ctx, s * 0.42);
      ctx.fill();
      ctx.restore();
    }
  }

  private drawHazards(ctx: CanvasRenderingContext2D) {
    const u = this.u;
    for (const h of this.hazards) {
      const sc = Math.min(1, (this.outer - h.d) / (80 * u));
      if (sc <= 0.02) continue;
      const { x, y } = this.pos(h.a, h.d);
      const L = 16 * u * sc;
      const W = 7 * u * sc;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(h.a); // local +x points outward; shard leads with its inner tip
      ctx.beginPath();
      ctx.moveTo(-L, 0);
      ctx.lineTo(0, W);
      ctx.lineTo(L * 0.5, 0);
      ctx.lineTo(0, -W);
      ctx.closePath();
      ctx.globalCompositeOperation = 'lighter';
      ctx.strokeStyle = `rgba(${C.hazard},0.28)`;
      ctx.lineWidth = 8 * u;
      ctx.lineJoin = 'round';
      ctx.stroke();
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = `rgb(${C.hazard})`;
      ctx.fill();
      ctx.fillStyle = '#fff1f2';
      ctx.beginPath();
      ctx.arc(-L * 0.35, 0, 1.8 * u, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
  }

  private drawPlayer(ctx: CanvasRenderingContext2D) {
    const p = this.p;
    if (!p.alive) return;
    const u = this.u;
    const { x, y } = this.pos(p.a, this.R);
    const r = PLAYER_R * u * (1 + p.flip * 0.4);

    ctx.globalCompositeOperation = 'lighter';
    const g = ctx.createRadialGradient(x, y, 0, x, y, r * 3.6);
    g.addColorStop(0, `rgba(${C.ring},0.55)`);
    g.addColorStop(1, `rgba(${C.ring},0)`);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, r * 3.6, 0, TAU);
    ctx.fill();
    ctx.globalCompositeOperation = 'source-over';

    ctx.fillStyle = `rgb(${C.player})`;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, TAU);
    ctx.fill();

    // direction chevron pointing where the orb is heading
    const tx = -Math.sin(p.a) * p.dir;
    const ty = Math.cos(p.a) * p.dir;
    const nx = -ty;
    const ny = tx;
    const tipX = x + tx * (r + 9 * u);
    const tipY = y + ty * (r + 9 * u);
    const bx = x + tx * (r + 2 * u);
    const by = y + ty * (r + 2 * u);
    ctx.fillStyle = `rgb(${C.ring})`;
    ctx.beginPath();
    ctx.moveTo(tipX, tipY);
    ctx.lineTo(bx + nx * 3.5 * u, by + ny * 3.5 * u);
    ctx.lineTo(bx - nx * 3.5 * u, by - ny * 3.5 * u);
    ctx.closePath();
    ctx.fill();
  }

  private drawShocks(ctx: CanvasRenderingContext2D) {
    ctx.globalCompositeOperation = 'lighter';
    for (const s of this.shocks) {
      const k = Math.max(0, s.life / s.max);
      ctx.strokeStyle = `rgba(${s.color},${k.toFixed(3)})`;
      ctx.lineWidth = s.width * this.u * (0.4 + k);
      ctx.beginPath();
      ctx.arc(s.x, s.y, Math.max(0, s.r), 0, TAU);
      ctx.stroke();
    }
    ctx.globalCompositeOperation = 'source-over';
  }

  private drawParticles(ctx: CanvasRenderingContext2D) {
    ctx.globalCompositeOperation = 'lighter';
    for (const q of this.parts) {
      const k = Math.max(0, q.life / q.max);
      ctx.globalAlpha = k;
      ctx.fillStyle = `rgb(${q.color})`;
      const s = q.size * (0.4 + 0.6 * k);
      ctx.beginPath();
      ctx.arc(q.x, q.y, s, 0, TAU);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
  }

  private drawPops(ctx: CanvasRenderingContext2D) {
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (const q of this.pops) {
      const k = Math.max(0, q.life / q.max);
      const grow = 1 + (1 - k) * 0.35;
      ctx.save();
      ctx.globalAlpha = Math.min(1, k * 2.5);
      ctx.translate(q.x, q.y);
      ctx.scale(grow, grow);
      ctx.font = `800 ${(q.size * this.u).toFixed(1)}px Orbitron, ui-sans-serif, system-ui, sans-serif`;
      ctx.shadowColor = `rgba(${q.color},0.9)`;
      ctx.shadowBlur = 12 * this.u;
      ctx.fillStyle = `rgb(${q.color})`;
      ctx.fillText(q.text, 0, 0);
      ctx.restore();
    }
  }
}
