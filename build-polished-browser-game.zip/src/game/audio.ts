/**
 * Tiny synthesized sound-effects engine (WebAudio, no assets needed).
 * The AudioContext is created lazily on the first user gesture.
 */
export type SfxName = 'flip' | 'collect' | 'graze' | 'combo' | 'death' | 'level' | 'start' | 'miss';

export class Sfx {
  private ctx: AudioContext | null = null;
  muted = false;

  ensure() {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      try {
        this.ctx = new AC();
      } catch {
        this.ctx = null;
        return;
      }
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume();
  }

  private tone(
    f0: number,
    dur: number,
    type: OscillatorType,
    vol: number,
    f1?: number,
    delay = 0,
  ) {
    const c = this.ctx;
    if (!c || this.muted || c.state !== 'running') return;
    const t = c.currentTime + delay;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    if (f1) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(c.destination);
    o.start(t);
    o.stop(t + dur + 0.03);
  }

  play(name: SfxName, n = 0) {
    switch (name) {
      case 'flip':
        this.tone(560, 0.07, 'square', 0.035, 240);
        break;
      case 'collect': {
        const f = 660 * Math.pow(2, Math.min(n, 24) / 12);
        this.tone(f, 0.14, 'sine', 0.2);
        this.tone(f * 2, 0.08, 'triangle', 0.05, undefined, 0.01);
        break;
      }
      case 'graze':
        this.tone(1300, 0.09, 'triangle', 0.06, 2300);
        break;
      case 'miss':
        this.tone(220, 0.18, 'triangle', 0.05, 110);
        break;
      case 'combo':
        [0, 4, 7, 12].forEach((s, i) =>
          this.tone(523 * Math.pow(2, s / 12), 0.16, 'triangle', 0.1, undefined, i * 0.05),
        );
        break;
      case 'level':
        [0, 7, 12, 19].forEach((s, i) =>
          this.tone(392 * Math.pow(2, s / 12), 0.22, 'sawtooth', 0.04, undefined, i * 0.08),
        );
        break;
      case 'death':
        this.tone(460, 0.75, 'sawtooth', 0.14, 40);
        this.tone(90, 0.55, 'square', 0.1, 30);
        break;
      case 'start':
        this.tone(300, 0.25, 'triangle', 0.1, 900);
        break;
    }
  }

  setMuted(m: boolean) {
    this.muted = m;
  }
}
