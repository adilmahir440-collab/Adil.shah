import { useEffect, useRef, useState } from 'react';
import { OrbitEngine, type Snapshot } from './game/engine';
import { useHighScores } from './hooks/useHighScores';
import { Hud } from './components/Hud';
import { GameOverScreen, PauseScreen, StartScreen } from './components/Screens';

const INITIAL: Snapshot = {
  phase: 'menu',
  score: 0,
  combo: 0,
  multiplier: 1,
  level: 1,
  muted: false,
};

export default function App() {
  const { scores, best, qualifies, addScore } = useHighScores();

  const [snap, setSnap] = useState<Snapshot>(INITIAL);
  const [over, setOver] = useState<{ score: number } | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [rank, setRank] = useState(-1);

  // The engine owns all game state; React only mirrors coarse events for the UI.
  const [engine] = useState(
    () =>
      new OrbitEngine({
        onChange: (s) => setSnap(s),
        onGameOver: (score) => {
          setOver({ score });
          setSubmitted(false);
          setRank(-1);
        },
      }),
  );

  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    return engine.attach(c);
  }, [engine]);

  const qualifiesNow = !!over && qualifies(over.score);
  const needsName = snap.phase === 'over' && qualifiesNow && !submitted;

  // Don't allow instant-restart to swallow keystrokes while the player types initials.
  useEffect(() => {
    engine.setLocked(needsName);
  }, [engine, needsName]);

  const handleSave = (name: string) => {
    if (!over) return;
    const r = addScore(name, over.score);
    setRank(r);
    setSubmitted(true);
  };

  const newBest = !!over && over.score > 0 && (rank === 0 || (needsName && over.score > best));
  const playing = snap.phase === 'playing';

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-[#03010a]">
      <canvas ref={canvasRef} className="touch-none absolute inset-0 block h-full w-full" />

      {(snap.phase === 'playing' || snap.phase === 'paused' || snap.phase === 'dying') && (
        <Hud
          score={snap.score}
          best={best}
          combo={snap.combo}
          multiplier={snap.multiplier}
          level={snap.level}
          playing={playing}
          onPause={() => engine.togglePause()}
        />
      )}

      {snap.phase === 'menu' && (
        <StartScreen
          scores={scores}
          muted={snap.muted}
          onPlay={() => engine.startGame()}
          onToggleMute={() => engine.toggleMute()}
        />
      )}

      {snap.phase === 'paused' && (
        <PauseScreen
          muted={snap.muted}
          onResume={() => engine.resume()}
          onRestart={() => engine.restart()}
          onMenu={() => engine.toMenu()}
          onToggleMute={() => engine.toggleMute()}
        />
      )}

      {snap.phase === 'over' && over && (
        <GameOverScreen
          score={over.score}
          newBest={newBest}
          needsName={needsName}
          scores={scores}
          rank={rank}
          onSave={handleSave}
          onRetry={() => engine.restart()}
          onMenu={() => engine.toMenu()}
        />
      )}
    </div>
  );
}
